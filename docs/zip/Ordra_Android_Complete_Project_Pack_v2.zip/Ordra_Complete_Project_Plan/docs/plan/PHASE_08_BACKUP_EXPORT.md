# Phase 8 — Backup, Restore & Export

## Implement
- Local export with explicit schema/version metadata.
- Restore preview, validation and duplicate handling.
- CSV export for user-readable order history.
- Optional encrypted backup design; cloud sync remains a separate future decision, not assumed.

## Exit criteria
[ ] Round-trip backup/restore passes tests.
[ ] Bad/old backups fail safely with useful messages.
[ ] Export excludes data the user did not choose where applicable.
