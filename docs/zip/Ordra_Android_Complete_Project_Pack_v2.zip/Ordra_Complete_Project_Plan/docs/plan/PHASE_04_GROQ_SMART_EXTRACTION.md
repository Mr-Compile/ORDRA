# Phase 4 — Groq-Assisted Smart Extraction

## Goal
Use Groq only where it materially improves messy OCR/order understanding.

## Architecture
Development may use local developer configuration excluded from Git. Production must not ship a reusable Groq secret in the APK. Use an Ordra-controlled backend/proxy before public release.

## Flow
OCR/local parser → if uncertain and user allows online analysis → redact/minimize sensitive data where possible → backend → Groq → strict structured response → schema validation → OrderDraft → user review.

## Implement
- Versioned extraction schema.
- Strict JSON validation and fallback on malformed AI output.
- Timeout/retry/rate-limit handling.
- Never let AI calculate trusted monetary totals without deterministic verification.
- Privacy disclosure for online analysis.
- Feature works without Groq through manual/local path.

## Exit criteria
[ ] API secret absent from release APK/repository.
[ ] Invalid AI responses cannot overwrite valid user data.
[ ] User always confirms before persistence.
[ ] Offline failure is graceful.
