# Phase 9 — Security, Privacy, Performance & Release Hardening

## Implement
- Dependency/security audit and release configuration review.
- Verify no secrets/tokens/debug endpoints/logged PII in release build.
- Optional biometric/app-lock design if implemented.
- Database migration tests across released schema versions.
- Performance profiling for startup, large lists, image/OCR flows.
- Accessibility audit.
- Privacy policy/data-safety inventory based on actual behavior.
- Crash handling/telemetry decision with privacy review.
- Signed release/AAB pipeline and versioning policy.

## Exit criteria
[ ] Release build passes lint/tests.
[ ] No critical/high unresolved security issue.
[ ] No destructive migration for normal upgrades.
[ ] Permissions are minimal and contextual.
[ ] Privacy documentation matches implementation.
