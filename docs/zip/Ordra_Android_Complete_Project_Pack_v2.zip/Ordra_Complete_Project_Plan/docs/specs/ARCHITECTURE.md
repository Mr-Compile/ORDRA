# Architecture Specification

UI (Compose) → ViewModel/state → Use cases → Repository contracts → data implementations → Room/DataStore/network/platform services.

Room is the source of truth for user orders. Online intelligence enriches drafts but does not become the authoritative store.

Use feature-first packages while keeping boundaries clear. Do not split into many Gradle modules until build/codebase size justifies it. Android platform services must be wrapped behind interfaces so business logic remains testable.
