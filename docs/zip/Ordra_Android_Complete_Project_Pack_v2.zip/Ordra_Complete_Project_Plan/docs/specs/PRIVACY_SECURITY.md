# Privacy & Security Specification

Ordra may process screenshots containing names, addresses, phone numbers, tracking IDs and payment/order details. Minimize collection and keep local processing as the default.

Rules:
- No permanent production API secret inside APK.
- Never commit secrets or local config.
- Ask only for permissions needed at the moment they provide value.
- Notification access is optional and clearly explained.
- Prefer Photo Picker over broad media/storage access.
- Do not upload screenshots by default.
- Online AI must disclose what is sent and minimize/redact sensitive fields where practical.
- Do not log full screenshots, addresses, tokens, order IDs or other sensitive payloads in production logs.
- Permanent deletion must be explicit.
