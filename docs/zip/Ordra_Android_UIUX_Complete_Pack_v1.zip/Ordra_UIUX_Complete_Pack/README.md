# ORDRA UI/UX Complete Pack v1

This pack is the canonical UI/UX specification for Ordra, an Android-only, local-first personal order and parcel manager.

Use it together with the Ordra Complete Project Pack and Frontend Complete Pack. This pack defines how every planned feature should look, behave, scale, and handle states. It does not replace architecture or data contracts.

## Canonical product
- Name: ORDRA
- Tagline: All your orders. One place.
- Platform: Android only
- UI: Jetpack Compose + Material 3
- Primary: #5B5FEF
- Secondary: #7C5CFC
- Local-first; Groq is optional online intelligence only.

## Start order
1. UI_UX_BIBLE.md
2. DESIGN_SYSTEM.md
3. COMPONENT_LIBRARY.md
4. SCREEN_SPECS.md
5. NAVIGATION_UX.md
6. ACCESSIBILITY.md
7. MOTION_AND_FEEDBACK.md
8. docs/plan/UI_IMPLEMENTATION_PHASES.md
9. docs/qa/UI_UX_QA.md
10. START_UI_IMPLEMENTATION_PROMPT.md
