# Ordra Android Frontend Pack

Complete frontend/UI implementation blueprint for Ordra, a local-only, offline-first Android order and parcel manager.

Canonical platform: Android only. UI: Kotlin + Jetpack Compose + Material 3.

Read in order: FRONTEND_BIBLE.md, FRONTEND_RULES.md, SCREEN_INVENTORY.md, NAVIGATION.md, design/DESIGN_SYSTEM.md, docs/plan/*.md, docs/qa/*.md, then ai-prompts/START_FRONTEND.md.

This pack complements the Ordra Complete Project Pack. It does not replace the product BIBLE/RULES.
