# ORDRA Integration & Data Contract Pack v1

This pack is the canonical integration contract for Ordra, an Android-only, local-first personal order and parcel manager.

## Purpose
Prevent drift between Compose UI, ViewModels, domain/use cases, repositories, Room, reminders, OCR, Groq Smart Import, notification assistance, analytics, backup/restore, and advanced order records.

## Hard constraints
- Android only: Kotlin + Jetpack Compose.
- Room/SQLite is the source of truth.
- Core features work offline.
- No accounts, cloud database, cloud sync, or custom backend.
- Groq is the only planned online dependency and is optional.
- ML Kit OCR is local.
- Never commit a real Groq API key.
- UI never talks directly to Room, Retrofit, WorkManager, or NotificationListenerService.

## Canonical flow
Compose -> ViewModel -> Use Case -> Repository -> Data Source/Service
Data changes return through Flow to the UI.

Read the files in this order:
1. CONTRACT_BIBLE.md
2. DOMAIN_MODELS.md
3. DATABASE_CONTRACT.md
4. REPOSITORY_USECASE_CONTRACT.md
5. UI_STATE_EVENT_CONTRACT.md
6. SMART_IMPORT_CONTRACT.md
7. REMINDERS_NOTIFICATION_CONTRACT.md
8. ANALYTICS_CONTRACT.md
9. BACKUP_RESTORE_CONTRACT.md
10. ERROR_VALIDATION_CONTRACT.md
11. INTEGRATION_TEST_MATRIX.md
12. INTEGRATION_PHASES.md
13. START_INTEGRATION_PROMPT.md
