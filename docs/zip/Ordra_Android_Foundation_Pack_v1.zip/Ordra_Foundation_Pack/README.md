# Ordra — Android Foundation Pack

**Working app name:** Ordra

Ordra is an Android-only, local-first smart order and parcel manager. It lets users save purchases from Shopee, TikTok Shop, Lazada and other sellers in one place, track delivery/payment status, prepare COD amounts, receive reminders, and later import orders intelligently from screenshots and supported Android notifications.

## Start here
1. Read `BIBLE.md`.
2. Read `RULES.md` and `AGENTS.md` before generating code.
3. Execute `docs/plan/PHASE_01_FOUNDATION.md` first.
4. Do not start OCR, Groq, notification listening, or marketplace automation until the required earlier phase is accepted.
5. Use `docs/qa/PHASE_01_QA.md` before marking Phase 1 complete.

## Pack structure
- `BIBLE.md` — product source of truth
- `RULES.md` — non-negotiable engineering/product rules
- `AGENTS.md` — instructions for AI coding agents
- `TECH_STACK.md` — approved Android stack
- `BRANDING.md` — name, visual identity, theme, logo/splash direction
- `docs/plan/` — single plan folder; no nested plan folders
- `docs/qa/` — acceptance and audit checklists
- `branding/theme_tokens.json` — starter design tokens
- `assets/` — starter vector logo and splash concepts

## Finalized v1 branding
The canonical project name is **Ordra**. Do not rename the app or reuse the former ParcelMind placeholder. The approved v1 palette and starter logo/splash specifications are in `BRANDING.md`, `branding/theme_tokens.json`, and `assets/`.
