# Phase 4 — Android Platform Assistance

## Scope
- Receive supported shared text/images/links via Android intents.
- Optional NotificationListenerService with explicit user-granted access.
- Parser adapters for supported shopping apps.
- Match notification updates to existing orders.
- Present suggested changes for confirmation when match confidence is not deterministic.

## Safety/product rules
- Never request marketplace passwords.
- Never scrape private app storage.
- Never claim official marketplace integration without verified authorization.
- Unknown notification formats must fail safely.
