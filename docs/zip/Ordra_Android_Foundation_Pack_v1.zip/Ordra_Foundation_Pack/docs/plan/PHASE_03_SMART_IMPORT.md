# Phase 3 — Screenshot Smart Import

## Pipeline
Screenshot → ML Kit OCR → local parser → optional Groq → OrderDraft → validation/confidence → review → normal repository save.

## Requirements
- Image picker/import.
- On-device OCR first.
- Detect likely platform and order fields.
- OrderDraft must be separate from persisted Order.
- Highlight missing/uncertain fields.
- User can correct everything before saving.
- Detect likely duplicates before persistence.
- Preserve app functionality when offline/Groq unavailable.
- Do not ship a permanent Groq secret inside the APK.

## Privacy
Minimize data sent online. Document what is sent. Consider redaction/minimization of names, addresses, phone numbers and unrelated screenshot content before remote processing.
