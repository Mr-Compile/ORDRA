# Phase 2 — Reminders

## Objective
Add reliable local delivery and COD reminders without requiring cloud services.

## Scope
- Notification channels.
- Runtime notification permission handling where required.
- WorkManager scheduling/rescheduling/cancellation.
- Delivery-day, 1-day-before, 2-days-before and custom reminders.
- COD amount in reminders when appropriate.
- Morning summary option for expected deliveries.
- Settings to enable/disable reminder types.

## Rules
- Editing ETA/COD/status must update affected scheduled work.
- Delivered/cancelled/refunded orders should not keep irrelevant delivery reminders.
- Denied notification permission must not break the app.
