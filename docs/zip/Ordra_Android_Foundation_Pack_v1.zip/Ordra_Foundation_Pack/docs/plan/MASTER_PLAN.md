# Ordra Master Plan

## Phase 1 — Foundation & Manual Orders
1A Project foundation and architecture
1B Room schema/repositories/use cases
1C Manual order create/edit/review
1D Home, order list, order detail
1E Search, filters, COD summaries, settings
1F Phase audit and QA

## Phase 2 — Reminders
WorkManager scheduling, local notifications, delivery reminders, COD preparation reminders, notification settings.

## Phase 3 — Smart Screenshot Import
Image selection, ML Kit OCR, local parsing, OrderDraft, optional Groq intelligence, confidence/validation, review and duplicate detection.

## Phase 4 — Android Platform Assistance
Android share target, NotificationListenerService, platform-specific notification parsers, order matching, confirmation-based status suggestions.

## Phase 5 — Purchase Lifecycle
Returns/refunds, warranty deadlines, receipts, stronger history and spending insights.

## Phase 6 — Backup & Advanced Infrastructure
Export/restore; evaluate cloud sync/accounts only if product need is proven; production AI proxy/backend.

## Gate rule
A phase cannot be marked complete until its QA checklist passes. Future phases must not compromise offline manual order management.
