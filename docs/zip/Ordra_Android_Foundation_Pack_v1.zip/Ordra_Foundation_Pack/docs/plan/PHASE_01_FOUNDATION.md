# Phase 1 — Foundation & Manual Orders

## Objective
Deliver a stable offline Android app capable of manually creating, viewing, editing, searching, filtering, archiving/restoring and deleting orders.

## 1A — Project Foundation
- Initialize Kotlin/Compose/Material 3 app.
- Configure Hilt, Room, DataStore, Coroutines/Flow, Navigation Compose, Coil and tests.
- Establish packages: app, core, data, domain, feature.
- Add light/dark Material theme from branding tokens.
- Add starter launcher/splash branding.
- Build must pass before 1B.

## 1B — Data Foundation
Create domain models for Order, OrderItem, Platform, OrderStatus, PaymentMethod, PaymentStatus and Category.

Minimum Order fields: id, platform, customPlatformName, sellerName, paymentMethod, paymentStatus, isCod, orderStatus, courier, trackingNumber, orderedAt, estimatedDeliveryStart, estimatedDeliveryEnd, deliveredAt, notes, createdAt, updatedAt, archivedAt.

OrderItem minimum: id, orderId, name, variant, quantity, unitPriceMinor, imageUri.

Price summary must support item subtotal, shipping, discount and final total using safe money representation.

Implement Room entities/DAO/mappers/repository and initial migration strategy.

## 1C — Manual Order Flow
Home → Add Order → Platform → Details/Items → Payment → Delivery → Review → Save.

Only essential fields should block save. Recommended minimum: order/item name, platform, total. Optional data must not make entry tedious.

## 1D — Core Screens
- Home summary: active, arriving soon, pending COD.
- Orders list.
- Order detail.
- Edit order.
- Archive/restore/delete with appropriate confirmation.

## 1E — Discovery & Settings
Search product/item, seller, tracking number, platform and notes. Filters: platform, status, payment/COD, category/date where available. Sort: newest, oldest, delivery soonest, highest/lowest total.

Settings via DataStore: System/Light/Dark theme, PHP default currency, default platform/payment, notification placeholders. Add About screen.

## Acceptance criteria
- App works without internet.
- User can complete the full manual order lifecycle.
- Room is the source of truth.
- Rotation/recomposition does not lose persisted order data.
- Back navigation is predictable.
- Money calculations are deterministic.
- No raw exceptions are shown to users.
- Build and required tests pass.
