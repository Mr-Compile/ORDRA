# Approved Tech Stack

## Android client
- Kotlin
- Jetpack Compose + Material 3
- MVVM + pragmatic Clean Architecture
- Navigation Compose
- Room / SQLite
- Hilt
- Kotlin Coroutines + Flow
- DataStore Preferences
- WorkManager
- Android Notification APIs
- NotificationListenerService (later phase, explicit permission)
- ML Kit Text Recognition for on-device OCR (smart import phase)
- Retrofit + OkHttp
- Kotlinx Serialization
- Coil
- JUnit + Android/Compose UI testing
- Gradle Kotlin DSL

## Optional later infrastructure
- Groq for intelligent extraction/normalization.
- Ktor backend/proxy for production secret protection and controlled AI requests.

## Explicitly not selected
- Flutter
- React Native
- Firebase as a foundation dependency
- Cloud account/sync system for V1
