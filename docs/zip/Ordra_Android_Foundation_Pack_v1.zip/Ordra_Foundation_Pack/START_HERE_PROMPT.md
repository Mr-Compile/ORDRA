# Copy/Paste Prompt for Coding AI

You are starting Ordra. This repository includes a product Bible, engineering Rules, AGENTS instructions, approved tech stack, branding foundation, plans and QA.

First, read in this order: BIBLE.md, RULES.md, AGENTS.md, TECH_STACK.md, BRANDING.md, docs/plan/MASTER_PLAN.md, docs/plan/PHASE_01_FOUNDATION.md, docs/qa/PHASE_01_QA.md.

Then audit the existing repository before coding. Report what exists, what conflicts with the documents, and a concise implementation plan for **Phase 1A only**.

Implement Phase 1A: Kotlin + Jetpack Compose + Material 3 foundation, Hilt, Room, DataStore, Coroutines/Flow, Navigation Compose, Coil, test foundation, package structure, light/dark theme tokens, and starter app branding. Do not implement Groq, OCR, screenshot parsing, notification listening, cloud sync, or future-phase features.

Build and test after implementation. Do not claim completion unless acceptance criteria are verified. If anything is blocked, report the blocker and evidence.
